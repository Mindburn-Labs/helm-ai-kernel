# VERIFY.md — how any session re-proves this package

Do not trust prose about this skill (including README.md). Run these gates.
Every command is read-only against helm-ai-kernel except the pack output path.

## 1. Manifest lint (the schema gate)

```bash
cd /Users/ivan/Code/Mindburn-Labs/helm-ai-kernel/core
go run ./cmd/skill_lint ../../helm-skills/skills/social-narrator/manifest.json
# expect: {"valid": true, ...}   exit 0
```

`skill_lint` enforces: required id/name/version/entry_point, `state` enum,
closed capability enum, `bundle_hash` sha256 format, non-empty `signature_ref`,
`self_mod_class` ∈ {C0,C1,C2,C3}, ≥1 input/output contract.

Cross-check against the published JSON schema:
`helm-ai-kernel/schemas/skill_bundle_manifest.json`
(required: id, name, version, description, entry_point).

## 2. Registry tests

```bash
cd /Users/ivan/Code/Mindburn-Labs/helm-ai-kernel/core
go test ./pkg/registry/skills/...
# expect: ok
```

## 3. Pack + bundle hash convention

```bash
# NEVER pack runtime output. Clean first:
rm -rf ../../helm-skills/skills/social-narrator/state ../../helm-skills/skills/social-narrator/drafts
find ../../helm-skills/skills/social-narrator -name __pycache__ -type d -exec rm -rf {} +

go run ./cmd/skill_pack ../../helm-skills/skills/social-narrator -o /tmp/social-narrator-skill.tar.gz
```

Hash convention (read before touching `manifest.json:bundle_hash`):

- `skill_pack` prints a deterministic **content hash**: sha256 over the
  concatenated contents of all files, sorted by path.
- At install, the registry (`core/pkg/registry/skills/verify.go`) computes
  **sha256 of the .tar.gz bytes** and requires it to equal
  `manifest.bundle_hash`; the trusted signature proof binds to that value
  (`TrustedSignatureProof.subject_hash`).
- Therefore: the dev copy of `manifest.json` records the `skill_pack` content
  hash as a drift detector. At a certified install, the pack is rebuilt, and
  the registry-side manifest record carries sha256 of the final .tar.gz as
  part of the signing ceremony. Any file change in this directory invalidates
  the recorded hash — re-run pack and update it.

## 4. Pipeline dry run (no network)

```bash
cd /Users/ivan/Code/Mindburn-Labs/helm-skills/skills/social-narrator
python3 src/social_narrator/main.py prompt \
  --item examples/sample_item.json --vertical ai_native_founders --platform linkedin
python3 src/social_narrator/main.py draft \
  --item examples/sample_item.json --text-file examples/sample_draft_text.md \
  --vertical ai_native_founders --platform linkedin
python3 src/social_narrator/main.py validate --draft drafts/<generated>.json
# expect: {"valid": true}
```

## 5. Fail-closed checks (all must FAIL the draft)

- Same body twice → second draft has `similarity_check.duplicate_of` set.
- Any claim verdict ≠ `supported` → draft status forced to `needs_research`.
- Body containing `buy now` / `price target` / `trading signal` /
  `guaranteed returns` → validation error.

## 6. Boundary checks (static)

```bash
grep -c "channel.send\|connector.invoke\|sandbox.exec" manifest.json   # expect 0
grep -rn "publish\|playwright\|selenium" src/                          # expect no matches
grep '"self_mod_class"' manifest.json                                  # expect "C0"
```

If any gate fails, the package — not the gate — is wrong. Fix and re-run.
