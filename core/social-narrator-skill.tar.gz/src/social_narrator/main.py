#!/usr/bin/env python3
"""mindburn.social-narrator CLI (entry_point).

Commands:
  ingest    Fetch enabled feeds from config/sources.json into state/inbox/.
  prompt    Print the assembled narrator prompt for one item + vertical.
  draft     Package an externally written body into a validated DraftArtifact.
  validate  Re-validate an existing draft artifact file.

Exit codes: 0 ok, 1 validation/usage error. Draft-only: there is deliberately
no publish command.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

sys.path.insert(0, str(Path(__file__).resolve().parent))

import artifact  # noqa: E402
import dedup  # noqa: E402
import intake  # noqa: E402
import narrate  # noqa: E402


def cmd_ingest(args) -> int:
    batch = intake.ingest(ROOT / "config" / "sources.json", ROOT / "state" / "inbox")
    print(json.dumps({"batch_id": batch["batch_id"], "items": len(batch["items"])}))
    return 0


def _load_item(path: Path) -> dict:
    data = json.loads(path.read_text())
    return data["items"][0] if "items" in data else data


def cmd_prompt(args) -> int:
    verticals = narrate.load_verticals(ROOT / "config" / "verticals.json")
    if args.vertical not in verticals:
        print(f"error: unknown vertical {args.vertical!r}; have {sorted(verticals)}", file=sys.stderr)
        return 1
    item = _load_item(Path(args.item))
    print(narrate.build_prompt(ROOT / "prompts" / "narrator.md",
                               verticals[args.vertical], item,
                               args.platform, args.brand))
    return 0


def cmd_draft(args) -> int:
    item = _load_item(Path(args.item))
    body = Path(args.text_file).read_text().strip()
    claims = [{
        "claim": args.claim or item["title"],
        "source_url": item["url"],
        "source_published_at": item["published_at"],
        "verdict": args.claim_verdict,
    }]
    memory = dedup.TopicMemory(ROOT / "state" / "topic_memory.json")
    sim = memory.similarity(f"{item['title']} {body}")
    risk = json.loads(Path(args.risk).read_text()) if args.risk else {
        "brand_risk": "low", "legal_risk": "low", "financial_advice_risk": "low",
    }
    draft = artifact.build_draft(
        drafts_dir=ROOT / "drafts", platform=args.platform, vertical=args.vertical,
        body=body, claims=claims, similarity=sim, risk=risk,
        required_approvals=[args.approver],
    )
    errs = artifact.validate_draft(draft)
    if errs:
        print(json.dumps({"valid": False, "errors": errs}, indent=2))
        return 1
    out = ROOT / "drafts" / f"{draft['draft_id']}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(draft, indent=2, ensure_ascii=False))
    memory.record(draft["draft_id"], f"{item['title']} {body}")
    print(json.dumps({"valid": True, "draft": str(out)}, indent=2))
    return 0


def cmd_validate(args) -> int:
    draft = json.loads(Path(args.draft).read_text())
    errs = artifact.validate_draft(draft)
    print(json.dumps({"valid": not errs, "errors": errs, "file": args.draft}, indent=2))
    return 0 if not errs else 1


def main() -> int:
    ap = argparse.ArgumentParser(description="mindburn.social-narrator (draft-only)")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("ingest").set_defaults(fn=cmd_ingest)

    p = sub.add_parser("prompt")
    p.add_argument("--item", required=True)
    p.add_argument("--vertical", required=True)
    p.add_argument("--platform", choices=["linkedin", "x"], default="linkedin")
    p.add_argument("--brand", default="Mindburn Labs")
    p.set_defaults(fn=cmd_prompt)

    p = sub.add_parser("draft")
    p.add_argument("--item", required=True)
    p.add_argument("--text-file", required=True, help="externally written draft body")
    p.add_argument("--vertical", required=True)
    p.add_argument("--platform", choices=["linkedin", "x"], default="linkedin")
    p.add_argument("--claim", default=None, help="factual claim made by the body (default: item title)")
    p.add_argument("--claim-verdict", choices=["supported", "unsupported", "needs_research"],
                   default="supported")
    p.add_argument("--risk", default=None, help="JSON file with brand/legal/financial_advice risk")
    p.add_argument("--approver", default="editorial_owner")
    p.set_defaults(fn=cmd_draft)

    p = sub.add_parser("validate")
    p.add_argument("--draft", required=True)
    p.set_defaults(fn=cmd_validate)

    args = ap.parse_args()
    return args.fn(args)


if __name__ == "__main__":
    sys.exit(main())
