# mindburn.social-narrator (v0.2, draft-only)

Converts verified AI/security/industry news into vertical-specific social media
**draft artifacts** through a money / people / tomorrow narrative lens.

**This skill cannot publish.** There is no publish command, no publish
capability in the manifest, and the `social-publish` policy pack DENYs
unattended publishing by default. Generation produces only `DraftArtifact`
JSON; turning a draft into a post is a separate, gated, human-approved act
that happens outside this skill.

## Pipeline

```
trusted sources (config/sources.json)
  → ingest + normalize            (intake.py, RSS/Atom, stdlib)
  → prompt assembly               (narrate.py + prompts/narrator.md)
  → external agent/human writes the body (the skill never calls an LLM itself)
  → dedup vs topic memory         (dedup.py, state/topic_memory.json)
  → DraftArtifact + validation    (artifact.py → drafts/drf_*.json)
  → human review queue            (outside the skill)
  → publish attempt               (outside the skill; policy.social-publish.v1)
```

## Boundaries (enforced, not aspirational)

| Boundary | Mechanism |
|---|---|
| No publishing | `channel.send` / `connector.invoke` / `sandbox.exec` are **not requested** in `manifest.json`; there is no publish code |
| No self-modification | `self_mod_class: C0`; feedback arrives as reviewable diffs, never self-applied |
| No unverified claims | a draft with any non-`supported` claim verdict is forced to `needs_research` |
| No financial advice | blocking patterns in `artifact.py` + `social.draft.financial_advice` DENY in the policy pack |
| No formulaic re-posting | near-duplicate detection (similarity ≥ 0.85 → `duplicate_of` set; publish gate requires `duplicate_of == null`) |
| Freshness | drafts expire after 48h (`expires_at`); publish gate requires freshness |
| No unattended browser posting | `social.publish.browser_automation` = DENY, no escalate variant |

## Usage

```bash
# 1. Assemble the narrator prompt for a source item
python3 src/social_narrator/main.py prompt \
  --item examples/sample_item.json --vertical ai_native_founders --platform linkedin

# 2. An agent (or human) writes the body from that prompt — outside this package

# 3. Package the body into a validated DraftArtifact
python3 src/social_narrator/main.py draft \
  --item examples/sample_item.json \
  --text-file examples/sample_draft_text.md \
  --vertical ai_native_founders --platform linkedin \
  --claim "The factual claim the body makes, traceable to the source"

# 4. Re-validate any draft
python3 src/social_narrator/main.py validate --draft drafts/drf_YYYY_MM_DD_NNN.json
```

`ingest` fetches live feeds; all feeds in `config/sources.json` ship
`enabled: false` — add real sources by reviewed commit.

## Contracts

- Input: `schemas/source_batch.v1.json` (untrusted_external)
- Output: `schemas/draft_artifact.v1.json` (internal_review_only, not promotable)
- Manifest: `manifest.json` — validates against
  `helm-ai-kernel/schemas/skill_bundle_manifest.json` and `cmd/skill_lint`
- Policies: `policies/social-narrator.safe.toml` (install/projection),
  `policies/policy.social-publish.v1.json` (publish gate)

## Install status

`state: candidate`. Install requires `InstallVerified` with a trusted
signature proof bound to `signature_ref` and the bundle hash — fail-closed by
design. The `bundle_hash` in this dev copy is the content hash reported by
`skill_pack` (see VERIFY.md for the exact convention); the authoritative
`sha256(tar.gz)` binding happens at sign/install time.

See **VERIFY.md** to re-prove every claim in this README.
