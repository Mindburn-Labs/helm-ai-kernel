A major agent framework just shipped unsigned skill installs as the default. No signature check, no execution receipt.

Money: if an unvetted skill exfiltrates your API keys or wipes a directory, that is not a bug report — that is a bill. Incident response, customer disclosure, downtime.

People: when the agent acts, someone still owns the outcome. "The framework allowed it" is not a name your customers accept.

Tomorrow: execution is getting commoditized. What you still own is the boundary that decides what your agents are allowed to do — and the receipts that prove it.

If your agent installed a skill yesterday, do you know which one, and who approved it?
