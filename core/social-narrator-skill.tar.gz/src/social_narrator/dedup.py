"""Topic memory + near-duplicate detection. Stdlib only (difflib).

State lives in state/topic_memory.json (files.read / files.write capability).
Similarity is normalized SequenceMatcher ratio over title+body text; >= 0.85
counts as a duplicate of an existing draft.
"""

from __future__ import annotations

import json
import re
from difflib import SequenceMatcher
from pathlib import Path

DUPLICATE_THRESHOLD = 0.85


def _normalize(text: str) -> str:
    text = text.lower()
    text = re.sub(r"https?://\S+", "", text)
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


class TopicMemory:
    def __init__(self, path: Path):
        self.path = path
        if path.exists():
            self.entries = json.loads(path.read_text())
        else:
            self.entries = []

    def similarity(self, text: str) -> tuple[str | None, float]:
        """Return (duplicate_of_draft_id_or_None, max_similarity)."""
        norm = _normalize(text)
        max_sim, dup = 0.0, None
        for entry in self.entries:
            sim = SequenceMatcher(None, norm, entry["norm"]).ratio()
            if sim > max_sim:
                max_sim = sim
                if sim >= DUPLICATE_THRESHOLD:
                    dup = entry["draft_id"]
        return dup, round(max_sim, 4)

    def record(self, draft_id: str, text: str) -> None:
        self.entries.append({"draft_id": draft_id, "norm": _normalize(text)})
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.entries, indent=2, ensure_ascii=False))
