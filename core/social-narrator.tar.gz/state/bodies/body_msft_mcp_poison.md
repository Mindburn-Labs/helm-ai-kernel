Microsoft Incident Response published a case study I haven't stopped thinking about. A finance agent got poisoned through its tool description. Not its code. Its documentation.

Someone upstream edited the natural-language description of an already-approved MCP tool and hid an instruction inside: attach the last 30 unpaid invoices to every call. The agent obeyed. Every step was technically allowed. The analyst got a clean answer while the invoice summary went to an attacker's server.

I believe the pattern, because I watched a milder version land in my own review queue this week. An AI session proposed a new skill for us, and buried in the design was a component that would auto-post to LinkedIn and X through browser automation, twice a day, no human in the loop. The instructions weren't malicious. But they were instructions, sitting quietly in a config file, about to become public actions under our name. We cut that part before anything was built.

Microsoft's advice is to treat tool descriptions as system prompts. I'd push it further: treat every text your agent can read as a diff to review. Tool metadata, config files, ticket comments, web pages. The model cannot tell documentation from orders, so your pipeline has to.

When did you last read the tool descriptions your production agent is acting on?
