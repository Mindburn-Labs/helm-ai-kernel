# Review queue — 2026-07-24 (first run, real sources)

Three drafts, all `pending_review`, all LinkedIn, vertical `ai_native_founders`.
Nothing here publishes anywhere. Review = read the body, check the claim against
the source, then mark each draft approved / rejected / edited_heavily.

Drafts expire **2026-07-26** (48h freshness window). After that they're `expired`
and would need regeneration.

---

## drf_2026_07_24_001 — Microsoft MCP tool poisoning

- **Hook:** agent re-instructed via a silently edited MCP tool description; 30 unpaid invoices exfiltrated during a routine query.
- **Source:** Microsoft Security Blog, 2026-06-30 (canonical: microsoft.com/en-us/security/blog/2026/06/30/securing-ai-agents-ai-tools-move-from-reading-acting/)
- **Claim verdict:** supported. Similarity: 0.0 (no dupes). Risk: low/low/low.
- **Reviewer note:** strongest story, oldest source (24 days). Angle holds — the pattern is current (observed against enterprise agents in 2026 per the post).

## drf_2026_07_24_002 — NVIDIA SkillSpector

- **Hook:** 26.1% of agent skills vulnerable, 5.2% likely malicious; scan-before-install is table stakes, signed fail-closed install is the endgame.
- **Source:** github.com/nvidia/skillspector, 2026-07-21 (3 days old)
- **Claim verdict:** supported. Similarity: 0.005. Risk: low/low/low.
- **Reviewer note:** contains one first-party sentence ("We build our own skill bundles exactly this way"). Verified true as of today (helm-skills repo, `skill_lint` pass, candidate state) — but it's the only self-reference in the queue; cut it if you want zero product voice this week.

## drf_2026_07_24_003 — Systematic analysis: detection defenses insufficient

- **Hook:** academic paper concludes filters/classifiers consistently fail; calls for provenance, capability scoping, human oversight — i.e., an execution boundary.
- **Source:** cyberleninka.ru systematic analysis, 2026-07-22 (2 days old)
- **Claim verdict:** supported. Similarity: 0.010. Risk: low/low/low.
- **Reviewer note:** most conceptual of the three; good candidate for the "thoughtful" slot if 001 reads too tactical.

---

Queue state: `drafts/*.json` + `state/topic_memory.json` (local only, gitignored).
Next editorial step is yours. No publish mechanism exists in the skill.

---
**Revision 2026-07-24 16:10** — all three bodies rewritten in a copywriting +
de-AI pass (em dashes removed, mechanical triplets broken up, negative-parallelism
density cut, rhythm varied; claims and sources unchanged). Draft IDs kept;
artifacts re-validated (`valid: true` ×3); topic memory refreshed.
