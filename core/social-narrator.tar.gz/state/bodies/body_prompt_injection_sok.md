A systematic review of agentic coding assistants landed this week with a blunt conclusion: detection-based defenses don't hold. Adaptive attacks walk past filters and classifiers. The authors call for architectural mitigations instead: provenance, capability scoping, human oversight on high-impact actions.

I watched the miniature version of that play out the same week. An AI session designed a skill for our kernel. Polite, confident, well-structured. It invented three permission names that don't exist in our capability enum, and two manifest fields the schema doesn't have. Nothing about it looked dangerous. That was the dangerous part.

A linter caught it in milliseconds. Not a smart linter: a closed list. Eleven capabilities, anything else fails the build. No judgment call, no confidence score, nothing to sweet-talk.

That's the paper's thesis in one afternoon. If your defense depends on a reader deciding a request looks fine, eventually it will read a very convincing request. Put the gate somewhere that doesn't read.

Look at your agent's permission system: which parts are a list, and which parts are a judgment call?
