"""Prompt assembly for the narrative engine.

The skill does NOT call an LLM itself. It assembles the narrator prompt from
prompts/narrator.md + config/verticals.json + a normalized source item, and an
agent runtime (or a human) writes the draft body. The body plus its claims are
then packaged and validated by artifact.py.
"""

from __future__ import annotations

import json
from pathlib import Path

PLATFORM_MAX_CHARS = {"linkedin": 3000, "x": 280}


def load_verticals(config_path: Path) -> dict[str, dict]:
    data = json.loads(config_path.read_text())
    return {v["id"]: v for v in data["verticals"]}


def build_prompt(template_path: Path, vertical: dict, item: dict,
                 platform: str, brand_name: str, notes: str = "") -> str:
    template = template_path.read_text()
    return template.format(
        brand_name=brand_name,
        news_title=item["title"],
        news_source=item["source_name"],
        news_url=item["url"],
        news_published_at=item["published_at"],
        news_summary=item.get("summary", ""),
        vertical_label=vertical["label"],
        vertical_pain=vertical["pain"],
        money_frame=vertical["money_frame"],
        people_frame=vertical["people_frame"],
        tomorrow_frame=vertical["tomorrow_frame"],
        experience_notes=notes.strip() or "(none provided)",
        platform=platform,
        max_chars=PLATFORM_MAX_CHARS[platform],
    )
