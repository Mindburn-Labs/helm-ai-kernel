{
  "version": "evidence-pack-seal/v1",
  "pack_id": "pack",
  "index_hash": "181281907b00c49be8324ea40f59cc1410fc327e94a58c78851409c4a2a54dc0",
  "merkle_root": "e6442ec76e70995926f2aa05955901394a044b2c5a133f0b5b8998643a623380",
  "entry_count": 21,
  "profile": "dev-local",
  "signer": {
    "type": "file-dev",
    "key_id": "file-dev:a4c0a69527e6e648",
    "algorithm": "ed25519",
    "public_key": "66e91804584e47287a5e84ec459ab7e63541905b1248889e22b6c6c113b86370"
  },
  "anchor": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only",
    "time": "2026-06-04T14:21:26.248278Z"
  },
  "storage": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only"
  },
  "signed_at": "2026-06-04T14:21:26.248278Z",
  "signature": "d93d11e37165774ec481ef0d3edc7ad0eaab8b0cd577c840035c9cc34532584f0682e93d231bd6ea9d1dfeb4946bd95b2ebd318c4273e754e5cb5d0fbfbd5b0f"
}
