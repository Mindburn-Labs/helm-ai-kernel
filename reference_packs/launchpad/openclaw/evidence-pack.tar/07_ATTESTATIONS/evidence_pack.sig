{
  "version": "evidence-pack-seal/v1",
  "pack_id": "pack",
  "index_hash": "82c7277bad2b8a8568e520d87049fc8143421ff8cb6f4f313d62747026128774",
  "merkle_root": "87f39655e0d33f3ceee6e22920e7c6d9e32f868ddbcf71e81ad510ddaf630885",
  "entry_count": 21,
  "profile": "dev-local",
  "signer": {
    "type": "file-dev",
    "key_id": "file-dev:a4c0a69527e6e648",
    "algorithm": "ed25519",
    "public_key": "66e91804584e47287a5e84ec459ab7e63541905b1248889e22b6c6c113b86370"
  },
  "anchor": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only",
    "time": "2026-06-04T14:21:26.008755Z"
  },
  "storage": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only"
  },
  "signed_at": "2026-06-04T14:21:26.008755Z",
  "signature": "8711643aef1cc87d5876b621de6a46109354b728a344af7f63428d4aab03060538db54c44551efa0c6846a1d129b7159d369d8cc862ac3decf7f9e6f2f44a800"
}
