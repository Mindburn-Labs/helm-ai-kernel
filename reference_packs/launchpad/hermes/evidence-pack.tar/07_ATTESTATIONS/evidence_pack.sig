{
  "version": "evidence-pack-seal/v1",
  "pack_id": "pack",
  "index_hash": "4b5a22d16bdc2db31f5d9024f92980a4e399d89eafe5baf9521c679cdd91a63e",
  "merkle_root": "6d6e43f2c5f22c2720963e7a1a43e653bc2068535049067461777fe00f1e4edd",
  "entry_count": 21,
  "profile": "dev-local",
  "signer": {
    "type": "file-dev",
    "key_id": "file-dev:a4c0a69527e6e648",
    "algorithm": "ed25519",
    "public_key": "66e91804584e47287a5e84ec459ab7e63541905b1248889e22b6c6c113b86370"
  },
  "anchor": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only",
    "time": "2026-06-04T14:21:25.531368Z"
  },
  "storage": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only"
  },
  "signed_at": "2026-06-04T14:21:25.531368Z",
  "signature": "6ac60959ee30473123ea3c40077fad16b0e64997b2a66d137921fadc146c713259581ae452ec3c5e3d6c7f1f1649c77054a0fcd120dde8dbfde0a056010c6b04"
}
