"""mindburn.social-narrator — draft-only social content pipeline.

This package ingests trusted news sources, applies a vertical narrative lens,
and emits DraftArtifact JSON objects for human review. It has no publish
capability by design (see policies/policy.social-publish.v1.json).
"""

__version__ = "0.2.0"
