NVIDIA scanned AI agent skills and found 26% contain vulnerabilities. 5% look outright malicious.

I read that the morning we were finishing our own skill bundle, so I went back and asked: what would have stopped a malicious version of us?

The uncomfortable answer: not our linter. A linter checks shape. What actually stops the bad version is that the bundle requests five capabilities from a closed enum, and "send anything anywhere" isn't one of them. If a capability isn't declared, it doesn't run. And nothing installs without a signature the registry verifies first.

Scanning is useful. Signatures are better. But what I keep coming back to is simpler: most agent runtimes install skills with the trust model of a VS Code theme. That was fine when skills were prompts. It stopped being fine the moment a skill could call tools with your credentials.

We spent the day making our bundle boring. Draft-only. No publish capability, not because we promised not to, but because the code never asks. The skill that can't betray you is the one that never had the capability.

What can your agent's most recently installed skill actually do?
