"""DraftArtifact construction + stdlib validation.

Validates against the draft_artifact.v1 contract WITHOUT external deps
(jsonschema is not available in the managed runtime). Checks mirror
schemas/draft_artifact.v1.json; if you change the schema, change CHECKS here
and in VERIFY.md together.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

DRAFT_ID_RE = re.compile(r"^drf_[0-9]{4}_[0-9]{2}_[0-9]{2}_[0-9]{3,}$")
URL_RE = re.compile(r"^https?://")
DATE_RE = re.compile(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}")
STATUSES = {"pending_review", "needs_research", "approved", "rejected", "expired"}
PLATFORMS = {"linkedin", "x"}
LENSES = {"money", "people", "tomorrow"}
CLAIM_VERDICTS = {"supported", "unsupported", "needs_research"}
RISK_LEVELS = {"low", "medium", "high"}
FRESHNESS_HOURS = 48

# Draft-blocking patterns (policy.social-publish.v1 social.draft.financial_advice).
FINANCIAL_ADVICE_PATTERNS = [
    "price target", "guaranteed returns", "buy now", "sell now", "trading signal",
]


def validate_draft(draft: dict) -> list[str]:
    errs: list[str] = []

    if not DRAFT_ID_RE.match(str(draft.get("draft_id", ""))):
        errs.append("draft_id must match drf_YYYY_MM_DD_NNN")
    if draft.get("status") not in STATUSES:
        errs.append(f"status must be one of {sorted(STATUSES)}")
    if draft.get("platform") not in PLATFORMS:
        errs.append(f"platform must be one of {sorted(PLATFORMS)}")
    if not draft.get("vertical"):
        errs.append("vertical is required")
    if not draft.get("body"):
        errs.append("body is required")

    lens = draft.get("narrative_lens")
    if not isinstance(lens, list) or not lens or not set(lens) <= LENSES:
        errs.append(f"narrative_lens must be a non-empty subset of {sorted(LENSES)}")

    claims = draft.get("claims")
    if not isinstance(claims, list) or not claims:
        errs.append("claims must be a non-empty array")
    else:
        for i, c in enumerate(claims):
            if not c.get("claim"):
                errs.append(f"claims[{i}].claim is required")
            if not URL_RE.match(str(c.get("source_url", ""))):
                errs.append(f"claims[{i}].source_url must be http(s)")
            if not DATE_RE.match(str(c.get("source_published_at", ""))):
                errs.append(f"claims[{i}].source_published_at must start with YYYY-MM-DD")
            if c.get("verdict") not in CLAIM_VERDICTS:
                errs.append(f"claims[{i}].verdict must be one of {sorted(CLAIM_VERDICTS)}")

    sim = draft.get("similarity_check", {})
    if "duplicate_of" not in sim:
        errs.append("similarity_check.duplicate_of is required (null allowed)")
    if not isinstance(sim.get("max_recent_similarity"), (int, float)):
        errs.append("similarity_check.max_recent_similarity must be a number")

    risk = draft.get("risk", {})
    for key in ("brand_risk", "legal_risk", "financial_advice_risk"):
        if risk.get(key) not in RISK_LEVELS:
            errs.append(f"risk.{key} must be one of {sorted(RISK_LEVELS)}")

    if not draft.get("required_approvals"):
        errs.append("required_approvals must be a non-empty array")

    for key in ("created_at", "expires_at"):
        try:
            datetime.fromisoformat(str(draft.get(key, "")).replace("Z", "+00:00"))
        except ValueError:
            errs.append(f"{key} must be ISO-8601 datetime")

    # Policy-derived blocking rules.
    body_lower = str(draft.get("body", "")).lower()
    for pat in FINANCIAL_ADVICE_PATTERNS:
        if pat in body_lower:
            errs.append(f"body matches financial-advice blocking pattern: {pat!r}")
    if claims and all(c.get("verdict") == "supported" for c in claims):
        pass
    elif draft.get("status") == "pending_review":
        errs.append("status must be needs_research when any claim is not supported")

    return errs


def next_draft_id(drafts_dir: Path, now: datetime) -> str:
    date_part = now.strftime("%Y_%m_%d")
    seq = 1
    if drafts_dir.exists():
        seq += sum(1 for p in drafts_dir.glob(f"drf_{date_part}_*.json"))
    return f"drf_{date_part}_{seq:03d}"


def build_draft(*, drafts_dir: Path, platform: str, vertical: str,
                body: str, claims: list[dict], similarity: tuple[str | None, float],
                risk: dict, required_approvals: list[str],
                now: datetime | None = None) -> dict:
    now = now or datetime.now(timezone.utc)
    all_supported = bool(claims) and all(c.get("verdict") == "supported" for c in claims)
    return {
        "draft_id": next_draft_id(drafts_dir, now),
        "status": "pending_review" if all_supported else "needs_research",
        "platform": platform,
        "vertical": vertical,
        "narrative_lens": ["money", "people", "tomorrow"],
        "body": body,
        "claims": claims,
        "similarity_check": {
            "duplicate_of": similarity[0],
            "max_recent_similarity": similarity[1],
        },
        "risk": risk,
        "required_approvals": required_approvals,
        "created_at": now.isoformat(),
        "expires_at": (now + timedelta(hours=FRESHNESS_HOURS)).isoformat(),
    }
