{
  "version": "evidence-pack-seal/v1",
  "pack_id": "HPR-2026-00001",
  "index_hash": "f8ead6346bd3f73a2b8d6daf02c71b87fe43e692685f25b6b3d449f63e61bf11",
  "merkle_root": "f837d9fd99a145e0a6cea0eeddfb4b020134e1a357a0bfca2b9095c2ad070a00",
  "entry_count": 23,
  "profile": "dev-local",
  "signer": {
    "type": "file-dev",
    "key_id": "file-dev:4a1dba92c1d08223",
    "algorithm": "ed25519",
    "public_key": "21cb238af97ac08b95d3d49bf5dab264a2868fb029d44f316eda07509e81a505"
  },
  "anchor": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only",
    "time": "2026-06-04T14:20:46.335364Z"
  },
  "storage": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only"
  },
  "signed_at": "2026-06-04T14:20:46.335364Z",
  "signature": "399c26dd34806377c6415ee694d1b38e399451f22d5a4a26ad66963280063e309ec4685ea8bc8cccf4694ccbfecff403f17fa619f41fb831520ee0b0f65be300"
}
