"""RSS/Atom intake. Stdlib only (urllib + xml.etree).

Fetches feeds listed in config/sources.json (enabled=true only) and normalizes
each entry into the source_batch.v1 item shape.
"""

from __future__ import annotations

import hashlib
import json
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

ATOM = "{http://www.w3.org/2005/Atom}"
USER_AGENT = "mindburn-social-narrator/0.2.0 (draft-only; +https://mindburnlabs.dev)"


def _text(el) -> str:
    return (el.text or "").strip() if el is not None else ""


def _parse_date(raw: str) -> str:
    raw = (raw or "").strip()
    for fmt in ("%a, %d %b %Y %H:%M:%S %z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%SZ"):
        try:
            return datetime.strptime(raw, fmt).astimezone(timezone.utc).isoformat()
        except ValueError:
            continue
    return datetime.now(timezone.utc).isoformat()


def parse_feed(xml_bytes: bytes, source_name: str) -> list[dict]:
    root = ET.fromstring(xml_bytes)
    items = []
    entries = root.findall(f".//{ATOM}entry") or root.findall(".//item")
    for entry in entries:
        if entry.tag == f"{ATOM}entry":
            title = _text(entry.find(f"{ATOM}title"))
            link_el = entry.find(f"{ATOM}link")
            url = link_el.get("href", "") if link_el is not None else ""
            published = _text(entry.find(f"{ATOM}published")) or _text(entry.find(f"{ATOM}updated"))
            summary = _text(entry.find(f"{ATOM}summary"))
        else:
            title = _text(entry.find("title"))
            url = _text(entry.find("link"))
            published = _text(entry.find("pubDate"))
            summary = _text(entry.find("description"))
        if not title or not url:
            continue
        raw_hash = hashlib.sha256(f"{title}|{url}".encode()).hexdigest()[:16]
        items.append({
            "item_id": f"itm_{raw_hash}",
            "title": title,
            "url": url,
            "published_at": _parse_date(published),
            "summary": summary,
            "source_name": source_name,
            "raw_hash": raw_hash,
        })
    return items


def fetch_feed(url: str, timeout: int = 20) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def ingest(sources_path: Path, out_dir: Path) -> dict:
    sources = json.loads(sources_path.read_text())["feeds"]
    batch_items = []
    for feed in sources:
        if not feed.get("enabled"):
            continue
        items = parse_feed(fetch_feed(feed["url"]), feed["name"])
        batch_items.extend(items)
    batch = {
        "batch_id": "btch_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S"),
        "fetched_at": datetime.now(timezone.utc).isoformat(),
        "items": batch_items,
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / f"{batch['batch_id']}.json"
    out.write_text(json.dumps(batch, indent=2, ensure_ascii=False))
    return batch
