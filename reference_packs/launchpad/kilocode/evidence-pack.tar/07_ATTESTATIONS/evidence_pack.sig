{
  "version": "evidence-pack-seal/v1",
  "pack_id": "pack",
  "index_hash": "2e66b1a511d8b9727aaf6cca09030896be95fedf843db0c78869a632e3673d3c",
  "merkle_root": "3f973fe34ff5e7dbd76c2586c4dd074ac1cc9e38041c01f709bc64458a214787",
  "entry_count": 21,
  "profile": "dev-local",
  "signer": {
    "type": "file-dev",
    "key_id": "file-dev:a4c0a69527e6e648",
    "algorithm": "ed25519",
    "public_key": "66e91804584e47287a5e84ec459ab7e63541905b1248889e22b6c6c113b86370"
  },
  "anchor": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only",
    "time": "2026-06-04T14:21:25.765456Z"
  },
  "storage": {
    "type": "local-dev",
    "uri": "local-dev://evidence-pack",
    "status": "development-only"
  },
  "signed_at": "2026-06-04T14:21:25.765456Z",
  "signature": "56d03f73137c18585ca18a9b0ccb6e568956ef8908407641766ed97fbeb5ea158189828d37ec8edb1f4982a8e7c8277aeeb99d7b8398921dd0acd3733b8d9e05"
}
